
package entities;

import java.util.ArrayList;


public class Course {
    private String course_code;
    private String course_name;
    private ArrayList<Section> sections;
    
    //Composition

    public Course() {
        sections = new ArrayList();
    }
    //constructor Overloading

    public Course(String course_code, String course_name, ArrayList<Section> sections) {
        this();
        this.course_code = course_code;
        this.course_name = course_name;
        for (int i=0;i<sections.size(); i++){
            this.sections.add(sections.get(i));
        }
      
    }
    
    //CopyConstructor
    public Course(Course course){
        this.course_code=course.getCourse_code();
        this.course_name=course.getCourse_name();
        this.sections= course.getSections();
    }
    
    //Getter setters

    public String getCourse_code() {
        return course_code;
    }

    public void setCourse_code(String course_code) {
        this.course_code = course_code;
    }

    public String getCourse_name() {
        return course_name;
    }

    public void setCourse_name(String course_name) {
        this.course_name = course_name;
    }

    public ArrayList<Section> getSections() {
        return sections;
    }

    public void setSections(ArrayList<Section> sections) {
        this.sections = sections;
    }
   
}
