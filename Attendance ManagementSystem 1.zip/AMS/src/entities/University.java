
package entities;

import java.util.ArrayList;
import javax.swing.JOptionPane;

public class University {
    public static ArrayList<Course> courses;
    public static ArrayList<User> users;
    public static ArrayList<Enrollment> enrollments;
    public static ArrayList<Attendance> attendances;
    public static ArrayList<WorkLoad> workloads;
    
  
    static{
        courses= new ArrayList();
        users= new ArrayList();
        enrollments= new ArrayList();
        attendances= new ArrayList();
        workloads= new ArrayList();
             
    }
    
    public static ArrayList<Section> dummySections1(){
        ArrayList<Section>dummySections= new ArrayList();
        dummySections.add(new Section("W1","Wednesday, Thursday","2:00pm to 3:15pm"));
        dummySections.add(new Section("W2","Monday, Friday","12:00pm to 1:15pm"));
        dummySections.add(new Section("W3","Tuesday, Thursday","10:30am to 11:45am"));
        return dummySections;
    }
    
    
    public static ArrayList<Section> dummySections2(){
        ArrayList<Section>dummySections= new ArrayList();
        dummySections.add(new Section("W1","Wednesday, Thursday","2:00pm to 3:15pm"));
        dummySections.add(new Section("W2","Monday, Wednesday","12:00pm to 1:15pm"));
       
        return dummySections;
    }
    
    
    
    
    
    
    public static void dummyUsers(){
        users.add( new User("Bilal Arif","bilal93","1122","Your first teacher name?","Ali","admin"));
        users.add( new Student("Asma Ismail","asma93","1122","Your first pet name??","Parrot","student","BSSE"));
        users.add( new Student("Aila Arshad","aila93","1122","Your first teacher name?","Khalil","student","BSCS"));
        users.add( new Teacher("Abdullah Yousaf","ay93","1122","Your first teacher name?","Ali","teacher",12345,50000,"CS"));
        users.add( new Teacher("Amna Zai","az93","1122","Your first teacher name?","Shumaila","teacher",12345,60000,"CS"));
    }
    
    public static void dummycourses(){
        courses.add(new Course("Mobile App Development","CC101",dummySections1()));
        courses.add(new Course("Web Development","CC102",dummySections2()));
        courses.add(new Course("Programming Fundamental","CC103",dummySections1()));
        courses.add(new Course("Object Oriented Programming","CC104",dummySections2()));
        courses.add(new Course("Data Structure","CC105",dummySections1()));
    }
    
    
    
    
    
    
    
    
    
    
    
    public static void dialogMsg(String msg){
        JOptionPane.showMessageDialog(null,msg);
    }
    
    //backend implementation
    
    public static boolean createCourse( Course c){
        if(c!=null){
            courses.add(c);
            return true;
        }
        else
            return false;
    }
    
}
