
package entities;

public class Student extends User {
    private String programe;

    public Student() {
    }

    public Student(String name, String u_name, String pass, String security_q, String security_a, String role,String programe) {
        super(name,u_name,pass,security_q,security_a,role);
        this.programe = programe;
    }
    
    //getter setter

    public String getPrograme() {
        return programe;
    }

    public void setPrograme(String programe) {
        this.programe = programe;
    }
    

   
    
    
    
}

