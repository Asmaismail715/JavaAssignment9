
package entities;

public class Attendance {
    private Student student;
    private Course course;
    private String date;
    private String time;
    private boolean a_mark;

    public Attendance() {
    }

    public Attendance(Student student, Course course, String date, String time, boolean a_mark) {
        this.student = student;
        this.course = course;
        this.date = date;
        this.time = time;
        this.a_mark = a_mark;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public Course getCourse() {
        return course;
    }

    public void setCourse(Course course) {
        this.course = course;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public boolean isA_mark() {
        return a_mark;
    }

    public void setA_mark(boolean a_mark) {
        this.a_mark = a_mark;
    }
    
    
    
    
}
