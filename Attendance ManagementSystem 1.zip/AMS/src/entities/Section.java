
package entities;

public class Section {
    private String name;
    private String days;
    private String timing;

    public Section() {
    }

    public Section(String name, String days, String timing) {
        this.name = name;
        this.days = days;
        this.timing = timing;
    }
    
    //getter Setter

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDays() {
        return days;
    }

    public void setDays(String days) {
        this.days = days;
    }

    public String getTiming() {
        return timing;
    }

    public void setTiming(String timing) {
        this.timing = timing;
    }
    
    
}
