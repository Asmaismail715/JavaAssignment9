
package entities;

public class Teacher extends User {
    private int emp_code;
    private double salary;
    private String   dept;

    public Teacher() {
    }

    

    public Teacher( String name, String u_name, String pass, String security_q, String security_a, String role,int emp_code, double salary, String dept) {
        super(name, u_name, pass, security_q, security_a, role);
        this.emp_code = emp_code;
        this.salary = salary;
        this.dept = dept;
    }
    
    //getter setter

    public int getEmp_code() {
        return emp_code;
    }

    public void setEmp_code(int emp_code) {
        this.emp_code = emp_code;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public String getDept() {
        return dept;
    }

    public void setDept(String dept) {
        this.dept = dept;
    }
    
    
    
}
